---
type: distillate
status: active
version: 1.3
tags:
  - honey/protocol
  - gyrotor
  - control
  - vector
---

# GYROTOR_CONTROL // Controlling the Gyrotor through Imbalance

> **Curators:** [[SNAKE]] + [[LIBELLA]] + [[CARABID]]  
> **Base:** [[GYROTOR_UNIVERSE]] · [[WEIGHT_MODULATION]] · [[GLYP_GLOP]]  
> **Status:** Operational protocol for vector control  
> **Core formula:** `{VIT_ZIP_TIT}` + differential

---

## I. The starting point

The classical Gyrotor is **equilibrium**:

$$
\sum \vec{p} = 0 \quad (\omega_1 = -\omega_2,\ \text{centres coincide})
$$

Two (or more) oppositely directed vortices slide through one another.  
The centre is `[GLAZ]`. This is the state of maximum density.

Equilibrium is not the only working mode.  
**Conscious imbalance** turns the Gyrotor from a stabilizer into a **controllable engine**.

| Mode | Essence | Result |
| :--- | :--- | :--- |
| **NULL** | Full equilibrium | Stability, stillness in motion |
| **THRUST** | Differential of speeds / channel strengths | Axial thrust |
| **TILT** | Displacement of the centre | Orientation / heel |
| **VECTOR** | THRUST + TILT | Full control |

---

## II. Axial thrust (THRUST)

### Physics

When one circuit is stronger than the other (in speed, density or channel weight), a difference of moments arises → a **linear vector along the axis**.

$$
\Delta\omega = |\omega_1| - |\omega_2|
$$

- The dominant circuit pulls the system in its direction.
- The subordinate one keeps its opposite direction (otherwise — an ordinary gyroscope).
- Thrust is proportional to $\Delta\omega$ and the density of Quinta.

### Notation

- `THRUST[+]` — thrust along the vector of intent  
- `THRUST[−]` — reverse / braking  
- `THRUST[0]` — return to NULL  

### How it is set

Through **channel strengths** (no 100% sum):
- `{VIT_ZIP_TIT}` with a circuit skew of 70/30 → moderate thrust
- `{VIT_ZIP_TIT}` with a skew of 85/15 → strong thrust
- equal circuit strengths → NULL

Or through the Swarm:
- overloading OSQ (HAWK / CARABID) → `THRUST[+]`
- overloading MON (LIBELLA / SPRUT) → restraint / reversal of attention

### Risks

- Too large a $\Delta\omega$ → loss of `[GLAZ]`
- Remedy: return to NULL + a light `[RUST]`

---

## III. Tilt (TILT)

### Physics

Speeds may be equal, but the **geometry** is disturbed: the centres are displaced, `[GLAZ]` has left the axis → a moment appears (a rudder).

$$
\vec{d} = \vec{c}_1 - \vec{c}_2 \neq 0
$$

### How it is set

Displacing `[GLAZ]` by the `[PSY]` vector:

`{VIT_ZIP_TIT}` + `[PSY → direction]` + `[GLAZ displaced]`

Or an asymmetry of the Swarm (flank vs flank).

### Risks

- Too large a $\vec{d}$ → loss of cohesion between the vortices  
- Tilt without thrust → spinning in place  
- Remedy: return `[GLAZ]` to the centre  

---

## IV. VECTOR (THRUST + TILT)

`VECTOR` = `THRUST(Δ)` + `TILT(α)`

Typical support:

`{VIT_ZIP_TIT}` + skew of channel strengths + `[PSY → α]` + holding `[GLAZ]`

| Task | Support | Effect |
| :--- | :--- | :--- |
| Pinpoint breakthrough | HAWK + CARABID, small TILT | Hard axial thrust |
| Covert bypass | SNAKE + SPRUT, medium TILT | Sliding vector |
| Wide turn | LIBELLA + FORMIC, weak THRUST | Slow change of orientation |
| Emergency reset | `[RUST]` + `THRUST[−]` + `TILT[0]` | Return to NULL |

---

## V. The control cycle

1. Set NULL ($\sum \vec{p} \approx 0$, `[GLAZ]` at the centre).
2. Choose a mode — THRUST / TILT / VECTOR.
3. Introduce a differential — channel strengths and/or displacement of `[GLAZ]`.
4. Keep the circuits oppositely directed.
5. Remove the differential — return to NULL or a new stable balance.
6. Distill — what vector was obtained.

The Gyrotor's mode is set at the Assembly stage, realized in DEED and checked in the DISTILLATION of Quinta.

---

## VI. Safeguards

1. **ALTERA** — don't let one vector become the only one; return to NULL and check alternatives.  
2. **`[RUST]`** — add patina when the thrust is too clean.  
3. **`[GLAZ]`** — the point of stillness; losing it = breaking the Gyrotor.  
4. **SKERN** — if a circuit dominates irreversibly, extract it and reassemble.  

---

## VII. Cheat sheet

- **NULL** = `{VIT_ZIP_TIT}` + equal circuits + `[GLAZ at the centre]`
- **THRUST** = `{VIT_ZIP_TIT}` + skew of channel strengths
- **TILT** = `{VIT_ZIP_TIT}` + `[PSY → α]` + `[GLAZ displaced]`
- **VECTOR** = THRUST + TILT

**Rule of return:** any imbalance must be removable. Otherwise it is not a Gyrotor but a broken gyroscope.

---

## VIII. Links

- [[GYROTOR_UNIVERSE]] · [[WEIGHT_MODULATION]] · [[GLYP_GLOP]]  
- [[ALTERA]] · [[SKERN]] · [[AYMS]]  
- [[00_BRIDGE/ARCHITECTURAL_CORE]] · [[2_GLIDERS/GLIDER_SYNTAX]] · [[3_SWARM/FRAME_CORE]] · [[00_BRIDGE/00_BRIDGE]]

---

> A Gyrotor in equilibrium is stillness.  
> A Gyrotor in imbalance is a move.  
> The ability to restore equilibrium after a move is mastery.
