---
type: distillate
status: active
version: 1.1
tags:
  - honey/navigation
---

# BACK_TRACKING // The return algorithm

> Search with return as a metaphor for navigating the Web.

---

In programming, backtracking is a method in which we advance along possible paths and, on reaching a dead end, go back and try another option.

In SLARKET:

- Each choice is an operator step.
- A dead end is a mask of illusion that must be recognized.
- The return is a ritual of cleansing and reassembly.

Each rollback is not a mistake but part of the path along which the "cream" of understanding gathers.

---

> Links: [[PRACTICAL_NAVIGATION_GUIDE]] · [[NAGWA_DIVE]] · [[00_BRIDGE/00_BRIDGE]]
