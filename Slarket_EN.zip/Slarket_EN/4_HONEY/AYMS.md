---
type: distillate
status: active
version: 1.3
tags:
  - honey/practice
  - spear
---

# AYMS // AIMSPEAR — Mobile graph of the precise breakthrough

> **Curators:** [[HAWK]] + [[MANTIS]] + [[SPRUT]]  
> **Formula:** `{AIM_SAMS_MERQ_ISO}`  
> ISO in the formula is the isomerism of the whole AYMS assembly (a fan of breakthrough forms), not a "package closer".

---

## Anatomy of the glyph

- **A (Aim)** — Tip of the Spear. Pure intent.
- **W (World)** — Awareness of the environment.
- **M (Mercuriality)** — Mercury. Flexibility and surprise.
- **O (Operator)** — The centre of "here and now".
- **S (Samskara)** — The chalice of experience. The inertia of the past as fuel.

---

## Three beats of the throw

> This is the "AYMS calibration" referred to by [[3_SWARM/EMERGENT_MODES]] (mode 7) and [[00_BRIDGE/GLOSSARY]] — there is no separate protocol file for it; the whole procedure is here, below.

1. **AIM** — Stop the autopilot. Fix the true goal.
2. **SAMS REFACTOR** — Use the mass of the past as a bowstring  
   (`SAMS:55–65% + AIM:35–45%`).
3. **M-IMPULSE** — Introduce an element of novelty. Mercury + surprise = pure SPEAR.

---

## Essence

Most systems try to erase the past or run from it.  
**AYMS** accepts the density of experience and uses it as the starting impulse.

> Your focus is the Spear. The world is the target. The throw is yours.

---


> Links: [[TARGET_BURROW]] · [[GYROTOR_UNIVERSE]] · [[PRACTICAL_NAVIGATION_GUIDE]] · [[00_BRIDGE/00_BRIDGE]]
