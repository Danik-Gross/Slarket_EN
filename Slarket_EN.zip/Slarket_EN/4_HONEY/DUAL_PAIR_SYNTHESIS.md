---
type: distillate
status: active
version: 1.2
tags:
  - honey/synthesis
---

# DUAL_PAIR_SYNTHESIS // Synthesis of dual pairs

> Base formula: `{IMAGE_1:XX%_IMAGE_2:YY%}`

---

## Examples

- `{CYBER_DOG:65%_ORNATE_KNIGHT:35%}` → CERBERUS WARDEN
- `{HAWK:75%_SNAKE:25%}` → high-frequency stealth hunter
- `{BIO_FLUID:55%_CYBER_STRUCTURE:45%}` → living-mechanical hybrid

---

## Recommendations

- The working range of accents is often 60/40 – 75/25, but this is not a law of a 100% sum.
- Each channel has **its own** strength; two channels can both be high.
- If you wish, add `[RUST]` to the heavier channel.
- **`[ISO]`** — only if isomerism of the pair is needed (a spectrum of forms in the Nagwa).

---

> Full weights protocol: [[WEIGHT_MODULATION]] · [[00_BRIDGE/00_BRIDGE]]
