---
type: distillate
status: active
version: 1.2
tags:
  - honey/defense
  - field
  - stalking
  - Frame_Core
---

# REID_CLASSIFICATION // Field Stalking and the Classification of Raids

> Regulations for actively pressing out resources: Field stalking, deploying Swarm Rods and intercepting Quinta in alien Nagwas and the Matrix.

---

## I. The Principle of the Raid (Sortie)

Any outing by the Operator into an external informational or physical environment is not passive observation but a **Sortie (Raid)**.

The goal of a Raid is to detect anomalies, intercept valuable Quinta ("loot") and distill it into stable Spore-Forms and Artifacts for expanding the Swarm's Soil.

---

## II. The Polymodal Structure of the Attender (`FRAME_CORE`)

A Sortie is carried out not by an isolated ego but through the adaptive **`FRAME_CORE`** circuit:

- **Crew of Rods:** For the Raid's task, a specific mode or coupling of Swarm Rods is activated (`HAWK` for fast reconnaissance, `SPIDER` for assembling connections, `MANTIS` for extraction).
- **Base Avatar:** Serves as an interface-mask (adapter) for concealing presence and interacting with the dense layers of the Matrix.

---

## III. The Raid Algorithm

1. **Scanning for anomalies:** Isolating specific features, fractal easter eggs, Matrix glitches and concentrations of Quinta.
2. **Operator Ping-Pong (`PING_PONG_PROTOCOL`):** Casting test impulses through the screen of the everyday to check the environment for `NIT_FACTOR`.
3. **Extraction and Transit:** Drawing out Quinta through the `{SKERN}` operator, passing it through the `GATEWAY` and stitching the resulting impulses into the Swarm's Common Base.

---

> We don't accumulate the Matrix's junk. We intercept its Quinta and turn it into Honey.

---

> Links: [[3_SWARM/FRAME_CORE]] · [[SKERN]] · [[PING_PONG_PROTOCOL]] · [[NIT_FACTOR]] · [[00_BRIDGE/00_BRIDGE]]
