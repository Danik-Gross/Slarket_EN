---
type: distillate
status: active
version: 2.1
tags:
  - honey/synthesis
  - weight
  - modulation
---

# WEIGHT_MODULATION // Weight Modulation and Channel Strength

> **Curators:** [[SPRUT]] + [[SPIDER]]  
> **Links:** [[GLIDER_SYNTAX]] · [[GYROTOR_UNIVERSE]] · [[DUAL_PAIR_SYNTHESIS]] · [[GYROTOR_CONTROL]]

---

## I. The Essence of Weight Modulation

Weight is the **strength, permeability or intensity of presence of an individual module/Rod** in an Assembly.

Slarket's operator logic has **no normalization "sum of weights = 100%"**.

This is not "dividing limited attention into parts" but **independent tuning of the amplitude of each channel**. Several Rods or Operators can work at high power at once. Channel conflicts are resolved not by the arithmetic of the sum but by resonant calibration, extraction through `{SKERN}` or the choice of a target `VECTOR`.

---

## II. Syntax

{BLOCK:NN%_BLOCK:NN%_BLOCK...}

- `:NN%` — explicitly stated channel strength relative to the module's full base power.
- A block without `:NN%` — works at full power ($100\%$) by default.
- The sum of percentages across an Assembly has **no upper limit** and is not reduced to anything.

### Example Assemblies:

- `{SNAKE:70%_DOG:50%_TIT_SIS}`
- `{HAWK:40%_MANTIS:80%}`
- `{FORMIC_BEE:60%_SPIDER}`
- `{HAWK:55%_CARABID:30%_RUST}`

---

## III. Practical Modes

|**Setting**|**Operator meaning**|
|---|---|
|**One channel > 70%**|Dominant accent of a Rod; the other modules serve as background dielectric or support.|
|**Several channels 50–80%**|Dense polyphonic resonance without cutting power.|
|**Channel without %**|Full base strength — the standard norm for stable Rods.|
|**Low weight (15–20%)**|A subtle overtone, patina or vector trace in the Ether.|

_Note:_ A weight below $15\%$ in practice turns into parasitic noise. This is a recommended calibration threshold.

---

## IV. Link with the Gyrotor and Thrust (`THRUST`)

The differential of weights between circuits sets axial thrust (`THRUST`):

- The difference in strength between active Rods or pairs shifts the equilibrium, making the **Gyrotor** rotate in the desired direction of phase space.
- Creating an axial impulse does not require lowering the system's total power.

---

## V. Modulator Operators

- **`[WEIGHT]`** — explicit call of the weight modulation mode.
- **`[WEIGHT_RUST]`** — applying patina and an ageing effect to the heavier element of an Assembly.
- **`[WEIGHT_GLAZ]`** — sealing and strengthening the point of stillness/fixation.
- **`[WEIGHT_FLASH]`** — an impulse jump of power on the selected channel.

> Weight is not a limitation of resources but the volume setting of each instrument in the Nagwa's orchestra.

> Links: [[DUAL_PAIR_SYNTHESIS]] · [[GLIDER_SYNTAX]] · [[GYROTOR_UNIVERSE]] · [[GYROTOR_CONTROL]] · [[SKERN]] · [[00_BRIDGE/00_BRIDGE]]
