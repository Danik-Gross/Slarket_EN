---
type: distillate
status: active
version: 1.1
tags:
  - slarket/honey
  - swarm
  - builds
---

# BUILDS // ASSEMBLIES AND COMBINATIONS OF THE SWARM

> Catalogue of working configurations of [[3_SWARM/FRAME_CORE]] rods.  
> Each assembly is a stable mode of Swarm functioning.

---

## I. Assembly principles

1. When one rod is activated, opposite vectors go into phase waiting `[_]`.
2. Weights can be modulated through [[WEIGHT_MODULATION]].
3. Conflicting nodes are extracted through `{SKERN}`.
4. An assembly strives for a working Gyrotor balance (NULL) or a conscious VECTOR — with no requirement of "completeness through ISO".

---

## II. Basic working modes

### 1. Assault afterburner
**Composition:** [[CARABID]] + [[HAWK]]  
**Weights:** CARABID 60% + HAWK 40%  
**Quinta:** Inertial breakthrough + high-frequency target capture.  
**Use:** Fast forceful entry, pushing through resistance.

### 2. Surgical capture
**Composition:** [[MANTIS]] + [[WASP]]  
**Weights:** MANTIS 70% + WASP 30%  
**Quinta:** Sniper intake + pinpoint injection.  
**Use:** Precise work with minimal side effects.

### 3. Base stabilization
**Composition:** [[BEE]] + [[SPIDER]] + [[DOG]]  
**Weights:** BEE 40% + SPIDER 30% + DOG 30%  
**Quinta:** Constructive service + fractal weaving + guarding of circuits.  
**Use:** Holding territory, growing structure, defending the perimeter.

### 4. Covert reconnaissance
**Composition:** [[SNAKE]] + [[LIBELLA]]  
**Weights:** SNAKE 55% + LIBELLA 45%  
**Quinta:** Mimicry + total overview.  
**Use:** Gathering information without exposure, working in a Nagwa.

### 5. Logistics circuit
**Composition:** [[FORMIC]] + [[SCOLOP]]  
**Weights:** FORMIC 50% + SCOLOP 50%  
**Quinta:** Collective computation + unkillable segmentation.  
**Use:** Distributing resources, fault-tolerant routes.

### 6. Reset and reassembly
**Composition:** [[VESPA]] + [[GATEWAY]]  
**Weights:** VESPA 60% + GATEWAY 40%  
**Quinta:** Destructuring impulse + gating.  
**Use:** Hard reset of the old configuration and transition into a new circuit.

### 7. Multifocus control
**Composition:** [[SPRUT]] + [[LIBELLA]] + [[DOG]]  
**Weights:** SPRUT 40% + LIBELLA 35% + DOG 25%  
**Quinta:** Multichannelness + 360° overview + guarding.  
**Use:** Running several flows at once while controlling boundaries.

---

## III. Axes of opposition (180°)

These pairs are in direct tension. Full simultaneous activation usually requires WEIGHT_MODULATION or a sequential mode.

| Vector A | Vector B | Nature of the tension |
| :--- | :--- | :--- |
| HAWK (0°) | SNAKE (180°) | Direct puncture ↔ mimicry |
| WASP (15°) | SCOLOP (210°) | Injection ↔ heavy armour |
| MANTIS (30°) | SPRUT (240°) | Concentration ↔ dispersion |
| CARABID (45°) | GATEWAY (270°) | Ram ↔ reception / gating |
| DOG (60°) | LIBELLA (300°) | Rigid perimeter ↔ total overview |
| FORMIC (90°) | VESPA (330°) | Assembly / computation ↔ destruction |

---

## IV. Compatibility rules

- **Synergy** — rods with an azimuth difference of 30–90° usually dock well.
- **Tension** — a difference of ~180° creates strong resonant conflict.
- **Buffer** — [[GATEWAY]] and [[DOG]] most often act as stabilizers in complex assemblies.
- **Cleaning** — when parasitic resonance appears, use `{SKERN}` on the conflicting node.

---

## V. Quick mode selection

| Task | Recommended assembly |
| :--- | :--- |
| Break through resistance | Assault afterburner |
| Pinpoint operation | Surgical capture |
| Hold and grow | Base stabilization |
| Reconnaissance without exposure | Covert reconnaissance |
| Distribute load | Logistics circuit |
| Reset the old | Reset and reassembly |
| Run several flows | Multifocus control |

---

## Links

- Registry of rods: [[3_SWARM/FRAME_CORE]]
- Weight modulation: [[WEIGHT_MODULATION]]
- Extraction of conflicts: [[SKERN]]
- Control deck: [[00_BRIDGE/00_BRIDGE]]
