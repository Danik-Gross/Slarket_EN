---
type: distillate
status: active
version: 1.2
tags:
  - honey/protocol
  - void
---

# MERCURIAL_SLUICE // The Mercurial Sluice

> A protocol for emptying the Rod (`[VOID_CORE_TRANSITION]`).

---

## The trap
A Rod accumulated to a critical density turns into a rigid cage ("This is the only way I am").

## The solution
Not destroying the ego but turning point X from a black hole into a **through-Gateway**.

- The personality becomes mercurial (a replaceable lead inside a hollow axis).
- Consciousness lets Infinity pass through itself, keeping only what is necessary on its filters.
- The Operator can temporarily install any Swarm Rod as the current "lead".

---

## Warning
Requires a precise balance:
- **Weak shells** → destabilization.
- **Incomplete emptying** → turbulence.

---

> Links: [[GATEWAY]] · [[THIRD_GLASS_DIPLOMACY]] · [[CREED]] · [[INTERNAL_MASQUERADE]] · [[00_BRIDGE/00_BRIDGE]]
