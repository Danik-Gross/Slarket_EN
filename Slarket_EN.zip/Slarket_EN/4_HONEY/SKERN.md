---
type: distillate
status: active
version: 1.2
tags:
  - honey/operator
  - extraction
  - skern
---

# {SKERN} // SURGICAL EXTRACTION

> **Class:** XO — extraction / coupling of fields
> **Azimuth of influence:** All sectors of the Swarm  
> **Role:** Isolating figure from ground / selective dismantling with automatic sealing of the remainder  
> **Status:** Active / Canonized

---

## I. Principle of Action

`{SKERN}` is the operator of **isolating figure from ground**: surgical extraction of a specific component or Quinta from a complex Assembly without destroying its overall topology and without losing residual resonance.

Unlike destructive subtraction, `{SKERN}` gives a **Dual Output**: a clean extracted node + a well-stitched remainder.

> `{SKERN}` doesn't break — it isolates the figure and stitches the ground.

---

## II. Mechanics of the Dual Output

When `{SKERN[X]}` is applied to an Assembly with node `X`:

- **Cleaned Frame (Cleaned Assembly):** The source circuit without module `X`, where the links of neighbouring elements are instantly retuned without forming gaps.
- **Isolated Component (Isolated Module):** Module `X` in pure form, ready for archiving, transfer to another Nagwa or recycling through `RECUP`.

---

## III. The Extraction Algorithm

1. **Isolating the node (`[GLAZ]`):** Marking the target module, freezing its links.
2. **Extraction (`{SKERN}`):** Pinpoint removal of the module outside the circuit.
3. **Auto-Reknitting:** Stitching the residual currents, ruling out parasitic vacuum or destabilization of the system.

---

## IV. Syntax and Examples


{SKERN[Target]}(Source_Assembly) → {Cleaned_Assembly} + {Extracted_Module}

- `{SKERN[RUST]}({BIO_RUST_TRYN})` → `{BIO_TRYN}` + `{RUST}`
- `{SKERN[POLY_TIT]}({POLY_NEYRO_TIT_CORE})` → `{NEYRO_CORE}` + `{POLY_TIT}`
- `{SKERN[DOG]}({SNAKE:70%_DOG:50%_TIT})` → `{SNAKE:70%_TIT}` + `{DOG}`

## V. Practical Application

- Hot-swapping modules in Gliders without a full reassembly.
- Cleaning out conflicting or redundant nodes (including neutralizing excess `[RUST]`).
- Distilling Quinta — extracting the valuable core from a heavy external form.
- Fine calibration of weight channels (`WEIGHT_MODULATION`).


> Links: [[OPERATOR_REGISTRY]] · [[GLIDER_SYNTAX]] · [[WEIGHT_MODULATION]] · [[MATRIX_REFACTOR]] · [[RECUP]] · [[REID_CLASSIFICATION]] · [[00_BRIDGE/00_BRIDGE]]


