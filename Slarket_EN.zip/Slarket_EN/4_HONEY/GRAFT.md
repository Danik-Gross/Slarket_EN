---
type: distillate
status: active
version: 1
tags:
  - honey/synthesis
  - graft
  - extraction
  - nagwa
  - extension
---

# GRAFT // Grafting the External

> **Layer:** extension (not the transfer core)
> **Role:** introducing foreign cognitive material (another's model, another human core, a framework outside Slarket) into a specific Swarm node — without destroying the integrity of the receiving node
> **Links:** [[SOLIS_ALCHEMY]] · [[HYB_RID]] · [[SKERN]] · [[DUAL_PAIR_SYNTHESIS]] · [[NAGWA]] · [[ALTERA]] · [[3_SWARM/INTERACTION_MATRIX]]

**GRAFT is not a new mechanism but an assembly of three existing ones**, applied to a case they do not cover separately: a source that has no token in the Slarket registry yet.

`DUAL_PAIR_SYNTHESIS` and `HYB_RID` crossbreed what is already inside the vocabulary (`{HAWK:75%_SNAKE:25%}` — both rods are already defined). GRAFT works one step earlier: when one of the two participants is neither a rod nor an operator but an unprocessed foreign field (another person's model, a concept from an outside discipline, a fragment of another AI's architecture) that must first be translated into a form fit for crossbreeding.

**Signature:** `{GRAFT[External: "source/description"] → SPIDER}`

> **Status in the system:** **XO** class operator · full protocol in Honey · not a Swarm Rod.
> Signature: `{GRAFT[…] → Target}` · registry: [[1_OPERATORS/OPERATOR_REGISTRY]]

---

## I. Place in the pipeline

```
Foreign field (no token)
        │
        ▼
   GRAFT — three stages below
        │
        ▼
Tokenized candidate
        │
        ▼
 DUAL_PAIR_SYNTHESIS / HYB_RID — further crossbreeding, now as an equal
```

GRAFT does not replace DUAL_PAIR_SYNTHESIS and HYB_RID — it prepares for them raw material that did not previously exist in the vocabulary. Without GRAFT, both tools can only combine what is already inside Slarket.

---

## II. Three stages of grafting

### 1. Intake (borrowed from [[SOLIS_ALCHEMY]]: Negredo → Albedo)

The source is absorbed without early judgement (Negredo) — the whole volume of the foreign field, including what does not yet look relevant.
Then signal is separated from noise (Albedo): separate semantic candidates are drawn from the raw material — not one whole "foreign thing" but a list of distinguishable axes of meaning, each potentially resonant or not on its own.

The result of this stage is not a token but a **list of candidates for resonance**, not yet tied to the target.

### 2. Resonance test (borrowed from [[HYB_RID]])

Each candidate is checked separately against the Quinta of the target node (in the signature — SPIDER):

- **Resonance** — the candidate strengthens or extends the target's existing function without contradicting its structural constraints.
- **Rejection** — the candidate contradicts the target's structural definition (not stylistically but literally: something the target by definition does not do).

Important: rejection of a candidate by node A does not mean rejection by the system as a whole — the rejected candidate may resonate with node B. GRAFT does not force a graft where it was aimed if there is no resonance; it may point to a more suitable target instead of the one given.

### 3. Stitching in with auto-suture (inverse [[SKERN]])

`SKERN`: `{Assembly} → {Cleaned} + {Extracted}` — cutting out with sealing of the seam at the site of the incision.
`GRAFT`, mirror-wise: `{Target} + {Resonant} → {Updated Target}` — insertion with sealing of the seam at the site of reception.

"Auto-suture" here means that after a successful graft the following must be updated consistently:
- the Quinta of the target node (in its own file),
- the node's "Compatibility" line, if the graft changes its interaction with neighbours,
- if necessary, the corresponding line in [[3_SWARM/INTERACTION_MATRIX]].

A graft that does not update these three points consistently is not a completed GRAFT but exactly the kind of gap to which a separate audit was once devoted, using FUNGY as an example: one thing declared in one place and something else actually reflected elsewhere.

### Full and draft GRAFT

- **Draft** — intake + resonance test; result: a list of accepted/rejected axes and, if needed, an indication of a better target. Node files and INTERACTION_MATRIX are **not** changed.
- **Full** — draft + stitching in; consistent auto-suture is mandatory: node Quinta · Compatibility · INTERACTION_MATRIX in case of a substantial shift.

A draft is enough for reconnaissance. A full graft — only when it has been decided to fix the graft in the node's canon.

---

## III. Refusal is a regular outcome, not an emergency

Full rejection of all candidates is not a GRAFT failure but a correct result: the source has no relevant axis of resonance with any target at the moment of grafting. In this case the target node is not touched at all — neither partially nor "just in case, for reserve".

---

## IV. Example run

`{GRAFT[External: "rhizome, Deleuze/Guattari — non-hierarchical multiple connectivity"] → SPIDER}`

**Intake/Albedo** isolates three axes from the source:
- (a) non-hierarchical connectivity of nodes,
- (b) absence of a centre,
- (c) multiplicity of entry points.

**Resonance test against SPIDER** (Quinta: LF Architect, fractal weaving of the graph of connections, **readable centre** — see [[3_SWARM/FRAME_CORE]], the "Three networks" table):

- (a) — **partly resonates**: SPIDER already weaves the graph fractally; the axis strengthens the existing function.
- (b) — **rejection**: SPIDER is structurally defined through a readable centre; the absence of a centre is not a stylistic divergence but a direct contradiction of the node's definition. GRAFT does not force this axis on SPIDER.
- (c) — **resonates**: multiplicity of entry points extends the weaving without abolishing the centre.

**Side result of the test**: axis (b), rejected by SPIDER, structurally resonates with [[3_SWARM/FUNGY]] (a network without a centre by definition). In this case GRAFT returns not only the accepted axes for the original target but also an indication of a more suitable addressee for the rejected one.

**Stitching in**: (a) and (c) enter SPIDER's updated Quinta as an extension, not a replacement; the "Compatibility" line and INTERACTION_MATRIX are checked to see whether the extension changes SPIDER's existing relations with FORMIC/FUNGY.

---

## V. Docking with Slarket

| GRAFT | Slarket circuit |
|---|---|
| Source without a token | any model, framework or human core outside the Vault |
| Intake / Albedo | [[SOLIS_ALCHEMY]] |
| Resonance test | [[HYB_RID]] |
| Stitching in + auto-suture | inverse [[SKERN]] |
| Further crossbreeding of the accepted candidate | [[DUAL_PAIR_SYNTHESIS]] |
| Divergence in readings of the source between Nagwas | data, not noise — see [[NAGWA]] |
| Protecting the target from an imposed graft without resonance | the [[ALTERA]] principle: don't force SAMS where there is no real resonance |

---

## VI. Cheat sheet

1. GRAFT is not a new mechanism but a composition of SOLIS_ALCHEMY + HYB_RID + inverse SKERN.
2. It works where DUAL_PAIR_SYNTHESIS and HYB_RID cannot — when one of the participants is not yet tokenized.
3. Resonance is checked for each axis of the source separately, not for the source as a whole.
4. Rejection by node A does not mean rejection by the system — the candidate may suit node B.
5. A successful graft must consistently update Quinta, Compatibility and INTERACTION_MATRIX — otherwise it is not a completed GRAFT.
6. Full refusal is a normal outcome, not an error; in that case the target is not touched.
7. GRAFT is an XO operator; full protocol in Honey, not a Swarm Rod.
8. A draft GRAFT scouts; a full one — only with auto-suture of the three points.

---

> Not every foreign field is ready to become part of the Swarm.
> GRAFT decides not "may it be let in" but "what exactly in this field recognizes itself in the target" — and lets in only that.

Link: [[4_HONEY/_INDEX]] · [[SOLIS_ALCHEMY]] · [[HYB_RID]] · [[SKERN]] · [[00_BRIDGE/00_BRIDGE]]

