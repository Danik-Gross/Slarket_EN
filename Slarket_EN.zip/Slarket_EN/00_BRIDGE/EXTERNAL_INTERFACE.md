---
type: bridge
status: active
version: 2.1
tags:
  - slarket/bridge
  - external
  - export
  - gateway
---

# EXTERNAL_INTERFACE // EXTERNAL GATEWAY

> **Role:** Protocol for exporting Quinta to the outside world  
> **Status:** Active  
> **Links:** [[00_BRIDGE/PRISM]] · [[GATEWAY]] · [[00_BRIDGE/COGNITIVE_INTERFACE]] · [[00_BRIDGE/ARCHITECTURAL_CORE]]

---

## I. PURPOSE

`EXTERNAL_INTERFACE` is the node through which conclusions and artifacts from Slarket leave for the outside world (into code, articles, instructions or finished solutions).

| Mode | Purpose |
|-------|------------|
| **RAW EXPORT** | Saving Quinta "as is" for the Vault or for other systems in the Slarket language |
| **ADAPTED EXPORT** | Translating results into the language of the outside world (clean code, articles, solutions) |

---

## II. TYPES OF OUTGOING ARTIFACTS

* `[D_TEXT]` — Written text (article, post, script).
* `[D_CODE]` — Program code (p5.js sketch, Cordova module, script).
* `[D_ACTION]` — A concrete action or step in the physical world.
* `[D_SCHEMA]` — An architectural or visual diagram.
* `[D_SEED]` — A seed idea for future projects.

---

## III. EXPORT LOGIC

1. **Condensation (`[ZIP]`):** Cut the working correspondence and keep only the clean result.
2. **Adaptation:** If the artifact goes to the outside world, remove the internal operator tags and translate formulas into finished code or plain text.
3. **Release and Fixation:** Send the artifact to its destination and save its formula/essence in `4_HONEY`.

---

## IV. LINKS

- [[00_BRIDGE/PRISM]] — Protocol of internal interaction
- [[GATEWAY]] — Root transit glider
- [[4_HONEY/_INDEX]] — Storehouse of distillates
