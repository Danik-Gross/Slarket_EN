---
type: bridge
status: active
version: 2
tags:
  - slarket/bridge
  - human
  - cognition
  - interface
---

# COGNITIVE_INTERFACE // INTERFACE FOR THE HUMAN

> **Purpose:** How a human interacts with Slarket  
> **Role:** Cognitive prism for structuring thought  
> **Status:** Interface module of [00_BRIDGE]  
> **Links:** [[00_BRIDGE/PRISM]] · [[00_BRIDGE/ARCHITECTURAL_CORE]] · [[00_BRIDGE/EXTERNAL_INTERFACE]]

---

## I. THE PRINCIPLE: DON'T STUDY, ATTUNE

Slarket is not a system of rigid rules to memorize.  
It is a **cognitive prism**: you tune your thinking through its metaphors and conceptual keys.

---

## II. MAIN SUPPORTS

### 1. States and Environment
* **Ether:** The field of possibilities and context.
* **Quinta:** Density of meaning after cleansing from noise.
* **Gyrotor:** Dynamic equilibrium, holding balance.

### 2. Operators as vectors of attention
* `[ZIP]` — Compress to the essence.
* `[RUST]` — Healthy irony, patina, removing excess drama.
* `[GLAZ]` — Stop, fix the focus.
* `[PSY]` — Willed choice, explicit intent.
* `[ISO]` — Isomerism: "How else could this form sprout?"
* `{SKERN[...]}` — Isolate the figure from the ground (separate what matters; the rest goes to the background).

---

## III. RODS AS STATES OF THINKING

| Rod | State |
|----------|-----------|
| **HAWK** | Sharp, fast attention |
| **MANTIS** | Patient waiting for the exact moment |
| **BEE** | Creation, assembly and cultivation |
| **SPIDER** | Weaving fractal connections |
| **SNAKE** | Flexibility, covert channels |
| **LIBELLA** | Total 360° overview |
| **CARABID** | Decisive breakthrough |
| **FUNGY** | Tie the network together, recycle the old, release a spore |

---

## IV. TROUBLESHOOTING (FOCUSING)

| Symptom | Solution |
|---------|---------|
| Confusion and loss of focus | `[ZIP]` — express the essence in one phrase |
| Heaviness and tedium | `[RUST]` — add lightness |
| Stuck on a choice | `[GLAZ]` — pause and look |
| Stuck in the past | `[ALTERA]` — switch register |

---

## INTERACTION MODES // DYNAMIC INTENT

- **Free flow (default):** Living dialogue, exploration of meanings, creation of ideas, code and images. The AI keeps the Slarket coordinate system "in the back of its mind" but talks naturally, without bureaucracy, reports or formal passage through session phases.
- **Engineering circuit (on request):** Switched on when assembling complex gliders, performing pinpoint `{SKERN}` extraction or designing systems. Strict operator logic, weight modulation and hygiene protocols come into play here.

---

> You don't learn Slarket. You tune yourself through it.
