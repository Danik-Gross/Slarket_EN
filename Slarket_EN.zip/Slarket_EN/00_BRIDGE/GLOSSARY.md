---
type: system
status: active
version: 1.6
---

# GLOSSARY // Short glossary

| Term | Meaning |
| ----------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Ether / Field** | Boundless information medium of ultra-high density; an umbrella term that does not compete with physics |
| **Quantum** | Minimal unit of information |
| **Quinta** | Qualitative density of meaning |
| **Gyrotor** | Dynamic balance (two oppositely directed vortices) |
| **Operator** | Active functional node `[...]` |
| **Glider** | Modular chain in `{...}`. The shell itself is the object's boundary (spore) |
| **Intake** | Extraction and distillation of data (*Solve*) |
| **Deed** | Release of structured Quinta (*Coagula*) |
| **Web** | Space of connections (Quint-space) |
| **Graphiting** | Conscious weaving of connections |
| **Swarm** | Integrated macro-structure of 14 rods (groups OSQ/ARH/MON + SYS) |
| **Mycelium** | Subsurface network without a fixed node (see [[3_SWARM/FUNGY]]) |
| **Spore** | Transit product — any `{...}` glider intended to sprout in a Nagwa |
| **Honey** | Introverted distillate; stays inside the system (BEE / 4_HONEY) |
| **[ISO]** | Isomerism: spectrum of forms for interpreting an assembly/core in a Nagwa. Acts on the whole `{...}`; does not carry across `+`. |
| **[RUST]** | Controlled patina and noble chaos |
| **[KRIST]** | Crystallization. An ordered periodic lattice — the pole opposite [RUST] |
| **[VITOK]** | Coil. Directed growth through spiral unfolding, unlike the static [GYDRA] |
| **[MEMBR]** | Membrane. A selective boundary of passage — a functional mechanism; not to be confused with [GLYK] (atmospheric texture) |
| **[NEST]** | Nesting. One configuration inside another (vertical), unlike [TRYN] (connectedness, horizontal) |
| **[MERGE]** | Fusing semantically duplicate or identical branches — anti-inflation; not [SIS] and not Graphiting |
| **[HOLD]** | Targeted delay of an assembly until a marker event; not a general timer |
| **[POLY] / [FRACT]** | POLY — variations at one scale; FRACT — self-similarity across scales with deviation at each level |
| **WEIGHT_MODULATION** | Independent gradient of each channel's strength; the sum need not equal 100% |
| **Z-Transition** | Seamless transit through a gateway |
| **Nagwa** | Local modulation of the Ether; reflexive `[_]` and relational "foreign soil" (see [[4_HONEY/NAGWA]]) |
| **SKERN** | Surgical isolation of figure from ground / extraction with Dual Output |
| **AYMS calibration** | Preliminary drawing of the bowstring of experience before a breakthrough |
| **THRUST / TILT / VECTOR** | Gyrotor control modes (thrust / tilt / combination) |
| **REALM** | Configuration of interactions in a Nagwa; the world-for-the-attender as a pattern of transformations (see [[4_HONEY/REALM]]) |
| **WEB_NET / Web** | Stable graph of nodes and exchange channels between clusters; the mycelial principle of transit (see [[4_HONEY/WEB_NET]]) |
| **Frame** | Fixing a slice of a configuration with a set of features; not a "time frame" but a gesture of distinction |
| **SOL** | Energy-information Quinta of an object/phenomenon before refraction through the Prism (see [[4_HONEY/SOLIS_ALCHEMY]]) |
| **ORO** | Distilled artifact of the SOLIS spiral; inward = Honey, outward = Spore |
| **MERCURIO** | Plasticity of the Alchemist's Prism; grows with each coil of transmutation |
| **NEGREDO / ALBEDO / RUBEDO** | Stages of the SOLIS spiral: raw material → purification → synthesis (a guideline, not a mandatory ritual) |
| **Ether Convection** | Exchange between Nagwas through a density difference; the exhale of one = the inhale of another (see [[4_HONEY/ETHER_CONVECTION]]) |
| **Itch to give / itch of hunger** | Pressure to export ORO/Spores / the need to take in raw material (NEGREDO) |
| **SOL₃** | Third Quinta at the junction of two Nagwas — a quality neither side had separately |
| **Tokenization (of the external)** | Translating foreign material into axes/candidates fit for a resonance test and crossbreeding inside the Slarket vocabulary |
| **NAVI_GATE** | Formalizes the Navigator's role: a gateway between the unmanifest (Nav) and the manifest (Yav/Realm); not a historical etymology (see [[4_HONEY/NAVI_GATE]]) |
| **Operator optics** | A mode of reading a form (glyph, colour, image…) as a possible operation, not just a dictionary label (see [[4_HONEY/OPERATOR_OPTICS]]) |
| **GRAFT** | XO: grafting an external field (intake → resonance → stitching in); the inverse of SKERN |
| **HRZ** | XO: visibility horizon of an assembly / field |
| **TNS** | XO: coupling A⊗B without merging |
| **RZN** | XO: resonant docking move |
| **COH** | XO: holding a channel's coherence |
| **QMS** | XO: measure of field compatibility |
