---
type: registry
status: active
version: 3.1
tags:
  - slarket/operators
---

# OPERATOR REGISTRY

> **Status:** Active node of [1_OPERATORS]  
> **Links:** [[00_BRIDGE/ARCHITECTURAL_CORE]] · [[2_GLIDERS/GLIDER_SYNTAX]] · [[1_OPERATORS/OPERATOR_LOGIC]]

---

## I. CO — Operators of Creation

They act strictly co-dependently, forming a single dynamic chord.

- **[INI]** — Initialization. Setting initial conditions.
- **[BIT]** — Bifurcation. Splitting and creating a potential difference.
- **[VIT]** — Circulation. Flows and continuous exchange.
- **[ZIP]** — Compression. Squeezing into a dense essence.
- **[PSY]** — Will Impulse. Vector of intent.
- **[TIT]** — Transmutation. Phase transition of quantity into quality.
- **[SIS]** — Superposition. Synchronization and resonant alliances.

---

## II. SO — Structural Operators

- **[ISO]** — Isomerism. Widens the spectrum of forms for interpreting an assembly/core as it sprouts in a Nagwa.  
  Inside `{...}` it acts on the **whole** assembly (position does not matter); it does not carry across `+`.  
- **[BIO]** — Biomorphism. The living, fluid principle.
- **[CYBER]** — Cyber-essence. Rigid algorithmic basis.
- **[GYDRA]** — Polymorphism. Many heads on a single base.
- **[NEYRO]** — Multichannelness. Synaptic network.
- **[GLAZ]** — Focusing. Point of absolute stillness (the Eye).
- **[RUST]** — Patina and controlled chaos.
- **[TRYN]** — Triangulation. Fractal connectedness.

---

## III. QO — Operators of Magnitude

- **[UNY]** — The One. Singularity.
- **[MULTY]** — The Many. Replication.
- **[POLY]** — The Diverse. Fractal multiplicity with differences.

---

## IV. FM — Functional Modules

- **[ROOT]** — Base rod, foundation.
- **[BRANCH]** — Tasty anomaly, mutation.
- **[WEIGHT]** — Channel strength/transparency (see [[4_HONEY/WEIGHT_MODULATION]]). No overall 100% sum per assembly.
- **[TARGET]** — Pinpoint puncture and target capture.
- **[FLASH]** — Instant quantum compression (the lemon neon of will).

---

## V. AO — Operators of Atmosphere

- **[BLYK]** — Glints and light effects.
- **[FLYK]** — Flows and fluctuations.
- **[GLYK]** — Membranes and transparency.
- **[SLYK]** — Slipperiness and viscosity.

---

## VI. XO — Extraction Operators and Field Coupling Protocols

A class of operators for refactoring assemblies, field dynamics and intersystem coupling. Extraction here is the result of deep work with boundaries, resonances and mutual adaptation of structures.

- **[SKERN]** — Surgical isolation of figure from ground / extraction of a node with automatic sealing of the remainder (Dual Output).  
  Syntax: `{SKERN[Target]}(Assembly) → {Cleaned} + {Extracted}`  
  Full protocol: [[4_HONEY/SKERN]]

- **[GRAFT]** — Grafting external cognitive material (introducing a foreign field through stages of intake, resonance test and stitching in).  
  Signature: `{GRAFT[External] → Target}`  
  Full protocol: [[4_HONEY/GRAFT]]

- **[HRZ]** — Horizon. Fixing the edge of a system's visibility and the boundaries of its circuits (what is inside and what is beyond the horizon).

- **[TNS]** — Tensor / Link. Placing a coupled pair $A \otimes B$ side by side without rigid merging (a bridge that preserves the nodes' autonomy).

- **[RZN]** — Resonance. Applying the docking move $\Omega$ — finding the carrier frequency and the delicate path of mutual response.

- **[COH]** — Coherence. Holding the channel over time, checking for absence of degradation ($\Xi \neq 0$) and monitoring the balance of information flow.

- **[QMS]** — Compatibility. Assessing the measure of resonant compatibility $Q(A,B)$ — an indicator of whether continuing synchronization is worthwhile.

---

## Special markers

- `[_]` — Underscore. Hidden channel of the Nagwa.
- **[VOID_CORE_TRANSITION]** — Emptying of the Rod.

---

> Output: [[00_BRIDGE/00_BRIDGE]]
