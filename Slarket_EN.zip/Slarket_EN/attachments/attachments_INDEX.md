---
type: moc
status: active
version: 2.1
tags:
  - slarket/visual
  - attachments
  - moc
---

# ATTACHMENTS // VISUAL STOREHOUSE OF QUINTA

> **Purpose:** Map of Slarket's visual distillates.  
> **Formats:** Images, symbols, diagrams, artifacts.

---

## I. PURPOSE

The images in this folder are not abstract illustrations but **visual distillates** that fix Quinta in space:

- They carry a particular frequency and Gyrotor vector.
- They serve as visual anchors for calibrating attention and entering Rod modes.
- They can be exported as `[D_SCHEMA]` artifacts.

---

## II. FOLDER STRUCTURE

attachments/  
├── attachments_INDEX.md    # This map of visual distillates
├── OPERATORS/      # Symbols and diagrams of how operators work
├── SWARM/          # Visualization of the 14 Swarm Rods (13 on the azimuth rose + FUNGY outside it), their links and the azimuth rose
└── ARTIFACTS/      # Images resulting from sessions, fixed diagrams

---
## III. CATALOGUE

### 📁 `/OPERATORS` — Operators

Symbols and visual diagrams of the tools of attention:

|**File**|**Description**|**Purpose**|
|---|---|---|
|`ZIP.png`|Compression — folding space into a point|Anchor of Quinta compression|
|`RUST.png`|Patina — noble chaos and ageing|Anchor of soft decrystallization|
|`GLAZ.png`|The Eye — point of absolute stillness|Anchor of instant fixation|
|`PSY.png`|Impulse of will — vector of intent|Anchor of vector selection|
|`ISO.png`|Isomerism — spectrum of structural forms|Anchor of multi-variant sowing|
|`BIT.png`|Bifurcation — branching|Anchor of process branching|
|`VIT.png`|Circulation — flow and exchange|Anchor of sustaining movement|
|`TIT.png`|Transmutation — change of quality|Anchor of phase transition|
|`SIS.png`|Superposition — resonant alliance|Anchor of test alignment|
|`TRYN.png`|Triangulation — fractal connection|Anchor of triadic engagement|
|`WEIGHT.png`|Modulation — independent weight amplitudes|Anchor of channel calibration|
|`TARGET.png`|Target — pinpoint puncture of the Ether|Anchor of focusing on the `ROOT-BRANCH` blueprint|
|`FLASH.png`|Flash — quantum compression|Anchor of the impulse jump|
|`SKERN.png`|Extraction — surgical extraction|Anchor of cutting away the excess|

### 📁 `/SWARM` — Swarm and Rods

Symbols of the 14 Swarm Rods (13 on the azimuth rose + FUNGY outside it), their group structures and the circular rose:

| **File** | **Description** | **Purpose** |
| -------------------- | ------------------------------------------------------------------------------------------- | ------------------------------------- |
| `FRAME_CORE.png` | Circular rose of 13 rods with azimuths + FUNGY outside the rose (SYS) | General plan of the Swarm, navigation |
| `HAWK_symbol.png` | HAWK symbol ($0^\circ$) — eagle, arrow, ray | Activates focused attention mode |
| `WASP_symbol.png` | WASP symbol ($15^\circ$) — wasp, sting, injection | Activates pinpoint injection mode |
| `MANTIS_symbol.png` | MANTIS symbol ($30^\circ$) — mantis, stillness | Activates waiting mode |
| `CARABID_symbol.png` | CARABID symbol ($45^\circ$) — ram, armour | Activates forceful breakthrough mode |
| `DOG_symbol.png` | DOG symbol ($60^\circ$) — dog, perimeter | Activates boundary defence mode |
| `FORMIC_symbol.png` | FORMIC symbol ($90^\circ$) — ant, route | Activates logistics and links mode |
| `BEE_symbol.png` | BEE symbol ($120^\circ$) — bee, honeycomb | Activates creation and laying mode |
| `SPIDER_symbol.png` | SPIDER symbol ($150^\circ$) — spider, web | Activates Web-weaving mode |
| `SNAKE_symbol.png` | SNAKE symbol ($180^\circ$) — snake, stealth | Activates camouflage and depth mode |
| `SCOLOP_symbol.png` | SCOLOP symbol ($210^\circ$) — centipede | Activates segmentation mode |
| `SPRUT_symbol.png` | SPRUT symbol ($240^\circ$) — octopus | Activates multi-capture |
| `LIBELLA_symbol.png` | LIBELLA symbol ($300^\circ$) — dragonfly | Activates panoramic overview |
| `VESPA_symbol.png` | VESPA symbol ($330^\circ$) — hornet, impulse | Activates compression and sting |
| `FUNGY_symbol.png` | FUNGY symbol — mycelium, spores (SYS, no azimuth, outside the rose) | Activates network, centreless mode |
| `GATEWAY_symbol.png` | GATEWAY symbol ($270^\circ$) — gateway, portal. **Not a Swarm Rod** — root transit node | Activates transit of assemblies |

### 📁 `/ARTIFACTS` — Session Artifacts

Visual diagrams and distillates created as a result of work:

- **Naming format:** `YYYY-MM-DD_short_title.png`



- **Examples:**
	- `2026-08-30_gateway_schema.png`
	- `2026-08-30_petri_dish_z_transition.png`


---

## IV. VISUAL STYLE AND COLOURS

| **Element** | **Colour** | **HEX** | **Purpose** |
| ----------------- | -------------------- | --------- | ------------------------- |
| **Ether / Background** | Dark blue | `#0a0e1a` | Base dielectric |
| **Quinta / Core** | Gold | `#f0c060` | Concentrated essence |
| **Operators** | Copper | `#c08040` | Symbols of links and dynamics |
| **RUST** | Rust | `#b06030` | Patina and mutations |
| **Nagwa** | Dark grey / Black | `#1a1a1a` | Hidden buffers and flasks |

> Links: [[00_BRIDGE]] · [[3_SWARM/FRAME_CORE]] · [[3_SWARM/FUNGY]] · [[GLIDER_SYNTAX]] · [[WEIGHT_MODULATION]] · [[00_BRIDGE/00_BRIDGE]]
