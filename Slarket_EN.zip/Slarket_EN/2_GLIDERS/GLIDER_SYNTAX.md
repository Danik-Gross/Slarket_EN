---
type: registry
status: active
version: 3.1
tags:
  - slarket/gliders
---

# GLIDER ARCHITECTURE AND SYNTAX

> **Status:** Active node of [2_GLIDERS]  
> **Links:** [[1_OPERATORS/OPERATOR_REGISTRY]] · [[00_BRIDGE/ARCHITECTURAL_CORE]] · [[1_OPERATORS/OPERATOR_LOGIC]]

---

## I. THE NATURE OF THE GLIDER

A **glider** is an autonomous package of modular assembly.  
The syntactic shell `{ ... }` is itself the object's boundary (spore / capsule).  
There is no separate "seal" or "encapsulation" operator.

A glider may be short or long.  
There is no artificial division into "fragment / complete".

---

## II. SYNTAX

- **Glider** — an autonomous package of modular assembly.  
  The syntactic shell `{ ... }` sets the object's boundary.  
- **Spore** — a glider *intentionally* sent outward to sprout in another Nagwa.  
  Not every `{...}` is a spore.
- Coupling of modules inside: `_`
- Several gliders: `+`
- Operators and rods within one coupling — no duplicates
- `CORE` — a suffix meaning "the core of this assembly" (`{CYBER_CORE}` = the core with the CYBER quality); it is not a separate operator in the registry

Examples:
- `{VIT_ZIP_TIT}`
- `{ISO_SNAKE}`
- `{CYBER_ISO_CORE}`
- `{ISO_SNAKE} + {CYBER_CORE}`
- `{SNAKE:70%_DOG:50%_TIT_SIS}`

---

## III. ASSEMBLY RULES

1. Each module occurs **only once** in a single coupling.
2. Redundant duplicates are cut off.
3. **`{ ... }`** sets the assembly's boundary. It is a spore only when there is an intent of outward transit; otherwise it is a working session glider or a Honey blank.
4. **ISO** means only **isomerism**:
   - ISO **inside** one `{...}` → isomerism of the **whole** assembly (ISO's position does not matter).
   - ISO **does not act** across `+`.
   - Need isomerism of one core in a superposition → separate package: `{ISO_SNAKE} + {CYBER_CORE}`.
5. Isomerism widens the spectrum of interpretive forms as the assembly sprouts in a Nagwa.
6. Isolating figure from ground / surgical extraction — **`{SKERN[…]}`**.

---

## IV. WEIGHT (channel strength)

Weight sets the **strength/transparency of each block**, with no overall sum of 100% for the whole assembly.  
`{SNAKE:70%_DOG:50%_TIT_SIS}`

- `SNAKE` — 70% of its strength  
- `DOG` — 50%  
- `TIT`, `SIS` — full strength by default

Full protocol: [[4_HONEY/WEIGHT_MODULATION]]

---

## V. BASE AND GATEWAY

- **[[GATEWAY]]** — the main transit construct (root). Accepts any `{...}` glider.

### Field-tested assemblies

| Formula | Purpose |
|---------|------------|
| `{VIT_ZIP_TIT}` | Dynamic Zero (starting the Gyrotor) |
| `{PSY_SO_ZIP}` | Psy-navigation |
| `{RUST_ZIP_TIT}` | Harlequin / tension release |
| `{ISO_ZIP_TIT}` | Isomerism of the ZIP+TIT chain (spectrum of transition forms) |
| `{UNY_TARGET_RUST}` | Target funnel |
| `{SO_GLAZ_QO}` | Holding the point of superposition |
| `{ISO_SNAKE}` | Isomerism of the Snake — a fan of forms in the Nagwa |

---

## VI. META-OPERATORS

- **`{SKERN[Target]}`** — surgical isolation of figure from ground / extraction with automatic sealing of the remainder.  
  Full protocol: [[4_HONEY/SKERN]]
- `{SKERN[Target]}(Source_Assembly) → {Cleaned_Assembly} + {Extracted_Module}`
- `{GRAFT[External] → Target}` — grafting an external field (XO)
- Coupling chain: `[HRZ] → [TNS] → [RZN] → [COH] → [QMS]`

---

> Output: [[00_BRIDGE/00_BRIDGE]]
