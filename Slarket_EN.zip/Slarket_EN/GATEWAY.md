---
type: glider
status: active
version: 3.2
tags:
  - slarket/glider
  - gateway
  - z-transition
---

# GATEWAY // GATEWAY

> **Azimuth:** 270° — Receiving vector (the vessel's engineering node)  
> **Role:** Point of entry / exit, gating of assemblies, Z-Transition  
> **State:** Sealed / Ready for gating  
> **Control:** [[00_BRIDGE]]

---

## I. Architecture of Coupling and Transit

`GATEWAY` gates **gliders** and **spores** — closed assemblies in `{...}` syntax.

The `{ ... }` boundary itself defines a whole package. No separate sealing operator is required; the package is self-sufficient.

### Package Rules:
1. **Integrity:** Package = any syntactically complete `{...}` glider.
2. **Uniqueness:** Modules inside a package are not duplicated; repeats are cut off automatically.
3. **The ISO operator (Isomerism):** The presence of `ISO` sets a **spectrum of structural isomers** (variability in the forms in which the Assembly sprouts when sown into a Nagwa).
4. **Independence of weights:** Channel strengths (`:NN%`) are set directly in the blocks and do not sum to $100\%$.
5. **Hybridization:** Any combinations of Swarm Rods and Operators are allowed inside `{...}` or through the `+` link operator.

---

## II. Package Classification

| Type | Example | Purpose |
| :--- | :--- | :--- |
| **Operator** | `{VIT_ZIP_TIT}` | Pure dynamic transformation of processes |
| **Weighted** | `{SNAKE:70%_DOG:50%_TIT}` | Assembly with a set amplitude modulation |
| **Isomeric** | `{ISO_SNAKE}` / `{CYBER_ISO_CORE}` | Assembly with a multi-variant spectrum of sprouting |
| **Hybrid** | `{HAWK_FLASH}` / `{SPIDER_PAUTINA}` | `FRAME_CORE` Rod + Operators |
| **Composite** | `{ISO_SNAKE} + {CYBER_CORE}` | Package-by-package assembly (`ISO` acts only on the `{...}` in which it stands) |

> **Note:** The surface gateway (`GATEWAY`) and the subsurface mycelium (`FUNGY`) divide functions: `FUNGY` grows nutrient channels and links nodes, while `GATEWAY` gates finished `{...}` packages through admission membranes.

---

## III. Three Phases of Transit

1. **THRESHOLD:** Checking the density of Quinta and the sealing of the `{...}` package.
2. **RESONANCE:** Attuning the Gyrotor's frequency and calibrating channel weights.
3. **Z-TRANSITION:** Sowing the Spore into an isolated transit flask (the "Third Glass") for controlled germination into the target Nagwa.

---

> Links: [[00_BRIDGE]] · [[FRAME_CORE]] · [[GLIDER_SYNTAX]] · [[FUNGY]] · [[4_HONEY/RECIPE_TRANSMISSION]] · [[THIRD_GLASS_DIPLOMACY]] · [[WEIGHT_MODULATION]] · [[00_BRIDGE/00_BRIDGE]]
> Channel layer between clusters: [[4_HONEY/WEB_NET]] · soil of sprouting: [[4_HONEY/NAGWA]] · pattern of the world: [[4_HONEY/REALM]]
