---
type: frame
status: active
azimuth: 15
frequency: HF
tags:
  - swarm/core
  - group/osq
---

# 🐝 WASP — Injector

- **Azimuth:** 15°
- **Group:** OSQ
- **Operator:** `{THREAD_INJECT}`
- **Hybrid:** "Parasitoid-Code"
- **Quinta:** Pinpoint expansion and covert resubordination of systems.

### Activation triggers
- A pinpoint injection of influence is needed
- Covert resubordination of a circuit is needed
- Surgical capture in tandem with MANTIS

### Anti-patterns (when not to engage)
- In tasks of mass construction
- When open forceful work is needed
- In base-stabilization mode

### Compatibility
- Amplifies: HAWK, MANTIS, SNAKE
- Conflicts with: BEE, FORMIC, FUNGY


---

Link: [[3_SWARM/FRAME_CORE]] · [[00_BRIDGE/00_BRIDGE]]
