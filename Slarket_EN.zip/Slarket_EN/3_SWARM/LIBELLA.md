---
type: frame
status: active
azimuth: 300
frequency: HF
tags:
  - swarm/core
  - group/mon
---

# 🦟 LIBELLA — Seer

- **Azimuth:** 300°
- **Group:** MON
- **Operator:** `{TIME_CROSS_FOCUS}`
- **Hybrid:** "Quadro-Gateway"
- **Quinta:** Total 360° overview and work with four vectors of time.

### Activation triggers
- A full overview of the situation is needed
- Work across several temporal layers is needed
- Control before a major decision or export

### Anti-patterns (when not to engage)
- When the maximum speed of a single vector is needed
- In tasks of a narrow forceful breakthrough

### Compatibility
- Amplifies: SPRUT, MANTIS, SNAKE
- Conflicts with: CARABID


---

Link: [[3_SWARM/FRAME_CORE]] · [[00_BRIDGE/00_BRIDGE]]
