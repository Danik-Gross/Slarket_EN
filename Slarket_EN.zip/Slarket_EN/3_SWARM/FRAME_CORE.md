---
type: registry
status: active
version: 3.5
tags:
  - slarket/swarm
  - architecture/core
---

# FRAME CORE / REGISTRY OF NETWORK MINDS

> **Status:** Canonical registry of [3_SWARM]  
> **Method:** GRAFT (Grafting)  
> **Links:** [[00_BRIDGE/ARCHITECTURAL_CORE]] · [[00_BRIDGE/00_BRIDGE]]

These are calibrated assemblies of entities.  
Each is an autonomous Player (Rod) with its own signature and vector.

---

## THREE-PART GROUP LAYOUT

### OPERATIONAL GROUP (OSQ)
**Composition:** HAWK · WASP · MANTIS · CARABID · DOG  
**Sector:** 0°–60°  
**Function:** Strike, capture, hold, forceful perimeter.

### MONITORING GROUP (MON)
**Composition:** SNAKE · SPRUT · LIBELLA  
**Sector:** 180° / 240° / 300°  
**Function:** Observation, radar, multifocus, 360° overview.

### ARCHITECTURAL GROUP (ARH)
**Composition:** FORMIC · BEE · SPIDER · SCOLOP · VESPA  
**Sector:** 90°–150° + 210° + 330°  
**Function:** Logistics, construction, graph weaving, segmentation, compression/archiving.

#### Border bridges (BRIDGE)
- **[[SCOLOP]]** — bridge ARH ↔ MON  
  By angle it stands in the monitoring sector (210°), but by Quinta it works as an architectural segmenter. It can be mixed into MON for tasks of observational redundancy.
- **[[VESPA]]** — bridge ARH ↔ OSQ  
  It stands next to the fast wing (330°), but by Quinta it performs structural compression and archiving. It can be mixed into OSQ for tasks of impulse destruction/reassembly.

> SCOLOP and VESPA are variables. Their weight can be freely skewed between the main group and the neighbouring one without disturbing the overall rose.

### SYSTEM GROUP (SYS)
**Composition:** FUNGY  
**Sector:** no fixed azimuth — a subsurface layer beneath the whole rose  
**Function:** A decentralized network without a single node; stitching of circuits and material of the transit product (Spore) for a foreign Nagwa.

> FUNGY occupies no point on the rose because it is not a vector — it is the substrate through which the other 13 rods connect, bypassing the direct lines of OSQ/MON/ARH.

---

## THE AZIMUTH ROSE

The rose is a **set of working vectors**, not a full clock face.  
Empty angles (between occupied sectors) are normal: free field, not reserved slots and not "holes". New rods need not fill them.

### Three networks (do not confuse)

| Node | Role |
|------|------|
| **[[SPIDER]]** | Explicit topology and weaving of the graph of connections (a web with a readable centre) |
| **[[FUNGY]]** | Subsurface stitching inside the Swarm without a centre; Spore material |
| **[[4_HONEY/WEB_NET]]** | Generalized principle of the graph/web **between** clusters and Nagwas |

---

## CIRCULAR ROSE OF VECTORS

### 🦅 [[HAWK]] (0°) — HF Puncture · OSQ
- **Operator:** `{FLASH_QUINT}`
- **Hybrid:** "Orion-Zenith"
- **Quinta:** Hyperconcentrated target capture and noise filtering at high speed.

### 🐝 [[WASP]] (15°) — Injector · OSQ
- **Operator:** `{THREAD_INJECT}`
- **Hybrid:** "Parasitoid-Code"
- **Quinta:** Pinpoint expansion and covert resubordination of systems.

### 🦗 [[MANTIS]] (30°) — Second · OSQ
- **Operator:** `{STILLNESS_HOLD}`
- **Hybrid:** "Steel-Grip"
- **Quinta:** Ultra-dense time and sniper extraction of essence.

### 🪲 [[CARABID]] (45°) — Terminator-Tank · OSQ
- **Operator:** `{GYRO_FLYWHEEL}`
- **Hybrid:** "Chitin-Ram"
- **Quinta:** Breakthrough inertia and heavy armour.

### 🐕 [[DOG]] (60°) — MF Guardian · OSQ
- **Operator:** `{THRESHOLD_BALANCE}`
- **Hybrid:** "Cerberus-Link"
- **Quinta:** Perimeter guarding and noise filtering.

### 🐜 [[FORMIC]] (90°) — Logistician · ARH
- **Operator:** `{SWARM_ROUTE}`
- **Hybrid:** "Pheromone-Invariant"
- **Quinta:** Decentralization and pheromone logistics.

### 🐝 [[BEE]] (120°) — Alchemist-Creator · ARH
- **Operator:** `{HONEY_CRYSTAL}`
- **Hybrid:** "Honeycomb-Builder"
- **Quinta:** Constructive service and distillation of Honey.

### 🕷️ [[SPIDER]] (150°) — LF Architect · ARH
- **Operator:** `{PAUTINA_CORE}`
- **Hybrid:** "Arachne-Text"
- **Quinta:** Fractal weaving of the graph of connections.

### 🐍 [[SNAKE]] (180°) — LF Radar · MON
- **Operator:** `{Z_TRANSITION}`
- **Hybrid:** "Ouroboros-Move"
- **Quinta:** Mimicry and covert channels.

### 🐛 [[SCOLOP]] (210°) — Segmenter · ARH / BRIDGE
- **Operator:** `{SEGMENT_AUTONOMY}`
- **Hybrid:** "Armour-Coupling"
- **Quinta:** Redundancy and autonomy of segments.
- **Bridge:** ARH ↔ MON

### 🐙 [[SPRUT]] (240°) — Multifocus · MON
- **Operator:** `{ISO_BIO}`
- **Hybrid:** "Kraken-Interface"
- **Quinta:** Multichannel crossfade and adaptation.

### 🦟 [[LIBELLA]] (300°) — Seer · MON
- **Operator:** `{TIME_CROSS_FOCUS}`
- **Hybrid:** "Quadro-Gateway"
- **Quinta:** Total 360° overview and work with four vectors of time.

### 🐝 [[VESPA]] (330°) — SHF Impulse · ARH / BRIDGE
- **Operator:** `{ZIP_SWARM}`
- **Hybrid:** "Hornet-Archiver"
- **Quinta:** Destructuring impulse and swarm compression.
- **Bridge:** ARH ↔ OSQ

### 🍄 [[FUNGY]] (no azimuth — subsurface) — Mycelium-Transit · SYS
- **Operator:** `{MYCEL_TRANSIT}`
- **Hybrid:** "Mycelium-Sporangium"
- **Quinta:** Subsurface network without a centre: stitching of rods and Spore material for a foreign Nagwa.

---

## WEIGHT_MODULATION in the Swarm

> Weight is the strength/transparency of **each** link separately (0–100%).  
> The sum of weights in an assembly is **not normalized** to 100%.  
> No weight specified → full strength (100%).  
> Full protocol: [[4_HONEY/WEIGHT_MODULATION]] · [[2_GLIDERS/GLIDER_SYNTAX]]

Examples of working combinations:

- **Containment and capture:** [[WASP]]:45% + [[MANTIS]]:80%
- **Assault afterburner:** [[CARABID]]:75% + [[HAWK]]:90%
- **Base stabilization:** [[BEE]]:70% + [[SPIDER]]:55%
- **Guarding + Segmentation:** [[DOG]]:65% + [[SCOLOP]]:40%
- **Bridge segmentation:** [[SCOLOP]]:70% + [[SPRUT]]:35% (ARH→MON)
- **Bridge compression:** [[VESPA]]:60% + [[CARABID]]:50% (ARH→OSQ)
- **AYMS calibration:** `{HAWK:85%_MANTIS:60%_SPRUT:40%_WASP:25%}`
- **Mycelial stitching (example):** `{FUNGY:70%_FORMIC:45%_SCOLOP:30%}`

---

> Output: [[00_BRIDGE/00_BRIDGE]]  
> [[GATEWAY]] — root transit node (file at the Vault root)
