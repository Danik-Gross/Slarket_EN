---
type: frame
status: active
azimuth: 60
frequency: MF
tags:
  - swarm/core
  - group/osq
---

# 🐕 DOG — MF Guardian

- **Azimuth:** 60°
- **Group:** OSQ
- **Operator:** `{THRESHOLD_BALANCE}`
- **Hybrid:** "Cerberus-Link"
- **Quinta:** Perimeter guarding and noise filtering.

### Activation triggers
- What has been captured needs to be held
- Incoming noise needs to be filtered
- Stabilization after a breakthrough

### Anti-patterns (when not to engage)
- At the stage of initial high-speed capture
- When maximum aggression and speed are needed
- In purely reconnaissance modes

### Compatibility
- Amplifies: CARABID, BEE, SCOLOP
- Conflicts with: HAWK (in excess)


---

Link: [[3_SWARM/FRAME_CORE]] · [[00_BRIDGE/00_BRIDGE]]
