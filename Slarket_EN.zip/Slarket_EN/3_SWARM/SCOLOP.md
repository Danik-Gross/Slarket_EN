---
type: frame
status: active
azimuth: 210
frequency: MF
tags:
  - swarm/core
  - group/arh
  - bridge
---

# 🐛 SCOLOP — Segmenter

- **Azimuth:** 210°
- **Group:** ARH / Bridge (ARH ↔ MON)
- **Operator:** `{SEGMENT_AUTONOMY}`
- **Hybrid:** "Armour-Coupling"
- **Quinta:** Redundancy and autonomy of segments.

### Activation triggers
- Segmentation and redundancy are needed
- The structure's survivability needs to be raised
- Transition between architectural and monitoring modes

### Anti-patterns (when not to engage)
- When maximum wholeness without segments is needed
- In tasks of an ultra-fast single strike

### Compatibility
- Amplifies: FORMIC, SPIDER, DOG, FUNGY
- Conflicts with: —
- Can be mixed into MON


---

Link: [[3_SWARM/FRAME_CORE]] · [[00_BRIDGE/00_BRIDGE]]
