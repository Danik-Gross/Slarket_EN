---
type: frame
status: active
azimuth: 90
frequency: MF
tags:
  - swarm/core
  - group/arh
---

# 🐜 FORMIC — Logistician

- **Azimuth:** 90°
- **Group:** ARH
- **Operator:** `{SWARM_ROUTE}`
- **Hybrid:** "Pheromone-Invariant"
- **Quinta:** Decentralization and pheromone logistics.

### Activation triggers
- Flows and routes need to be organized
- Decentralized coordination is needed
- Building stable logistics

### Anti-patterns (when not to engage)
- In tasks of pinpoint covert injection
- When impulse destruction is needed
- In pure assault mode

### Compatibility
- Amplifies: BEE, SPIDER, SCOLOP, FUNGY
- Conflicts with: WASP, VESPA


---

Link: [[3_SWARM/FRAME_CORE]] · [[00_BRIDGE/00_BRIDGE]]
