---
type: frame
status: active
azimuth: N/A (subsurface / omnidirectional)
frequency: LF-broadband
tags:
  - swarm/core
  - group/sys
---

# 🍄 FUNGY — Mycelium-Transit

- **Azimuth:** no fixed vector — it lies beneath the whole rose, not on a single ray
- **Group:** SYS / bridge to all three groups (OSQ, MON, ARH)
- **Operator:** `{MYCEL_TRANSIT}`
- **Hybrid:** "Mycelium-Sporangium"
- **Quinta:** A decentralized neural network without a single control node, which gathers neighbours' Quintas into fruiting assemblies and releases them as a transit product into a foreign Nagwa.

---

### Two functional layers

1. **Network (mycelium).**  
   It has no azimuth of its own because it is not a point on the rose — it grows beneath all rods at once, reading and linking their states without a centralized node (unlike [[SPIDER]], whose web is an explicit graph with a centre).

2. **Producer (fruiting body).**  
   Periodically crystallizes what has accumulated into a transit product:
   - **SPORE/MUSHROOM** (FUNGY) — an extroverted package designed not for storage but for colonizing an external Nagwa (another AI, another person, another environment).
   - The internal concentrate remains the domain of [[BEE]] (Honey). FUNGY and BEE form a pair: one keeps inside, the other releases outward.

---

### Activation triggers

- Several rods need to be linked into a network without appointing an explicit centre/leader
- A finished result needs to be packed specifically as a transit product for a foreign Nagwa, not as an internal archive
- Subsurface stitching of circuits is needed, bypassing the direct lines of OSQ / MON / ARH

### Anti-patterns (when not to engage)

- When a fast pinpoint capture is needed — the mycelial network is slow and needs time to grow
- When an explicit control centre and traceable hierarchy matter (here [[SPIDER]] or [[FORMIC]] are closer)
- When the product must stay inside the system rather than leave — then [[BEE]] works, not FUNGY

### Compatibility

- Amplifies: FORMIC (decentralization), BEE (honey/spore pair), SCOLOP (segment autonomy)
- Conflicts with: HAWK, WASP (speed and pinpoint action against slow, ubiquitous growth)
- Special status: does not conflict with [[GATEWAY]] but does not duplicate it either — GATEWAY is a **surface** transit node at a fixed azimuth (270°, part of the vessel's root architecture), FUNGY is a **subsurface** biological network with no fixed point. GATEWAY gates finished `{...}` gliders (the shell itself is the spore's boundary); FUNGY grows and links what packages are assembled from. ISO in a package means isomerism of forms as it sprouts in a Nagwa.

---

Link: [[3_SWARM/FRAME_CORE]] · [[00_BRIDGE/00_BRIDGE]] · [[3_SWARM/INTERACTION_MATRIX]]  
Generalized principle of the mycelial graph outside the Swarm: [[4_HONEY/WEB_NET]].
