---
type: matrix
status: active
version: 1.3
tags:
  - slarket/swarm
  - dynamics
---

# INTERACTION_MATRIX // MATRIX OF SWARM INTERACTIONS

> **Status:** Canonical  
> **Links:** [[3_SWARM/FRAME_CORE]] · [[4_HONEY/BUILDS]]

---

## Legend

- **Amplifies** — raises the density of Quinta when working together
- **Dampens / conflicts** — creates parasitic noise or reduced effectiveness
- **Can subordinate** — able to temporarily take over control

---

## Matrix

| Rod | Amplifies | Dampens / conflicts | Can subordinate |
| -------- | -------------------------- | -------------------- | --------------- |
| HAWK | MANTIS, WASP, CARABID | DOG, BEE, FUNGY | — |
| WASP | HAWK, MANTIS, SNAKE | BEE, FORMIC, FUNGY | — |
| MANTIS | HAWK, WASP, LIBELLA | CARABID (when rushed) | — |
| CARABID | HAWK, DOG | SPIDER, LIBELLA | — |
| DOG | CARABID, BEE, SCOLOP | HAWK (in excess) | — |
| FORMIC | BEE, SPIDER, SCOLOP, FUNGY | WASP, VESPA | — |
| BEE | FORMIC, SPIDER, DOG, FUNGY | HAWK, WASP | — |
| SPIDER | BEE, FORMIC, SCOLOP | CARABID | — |
| SNAKE | SPRUT, WASP, LIBELLA | DOG, BEE | — |
| SCOLOP | FORMIC, SPIDER, DOG, FUNGY | — | MON group |
| SPRUT | SNAKE, LIBELLA, HAWK | — | — |
| LIBELLA | SPRUT, MANTIS, SNAKE | CARABID | — |
| VESPA | HAWK, CARABID | FORMIC, BEE | OSQ group |
| FUNGY | FORMIC, BEE, SCOLOP | HAWK, WASP | — |

**Gateway (not a Swarm Rod):** [[GATEWAY]] — root transit node; it does not take part in the players' interaction matrix.  
**Mycelium:** [[3_SWARM/FUNGY]] (SYS group, no azimuth).

---

## Notes

- SCOLOP and VESPA are variable bridges. Their weight can be freely skewed.
- In a strong conflict, use `{SKERN}` to extract the interfering node.
- The matrix may be refined based on Feedback results.
