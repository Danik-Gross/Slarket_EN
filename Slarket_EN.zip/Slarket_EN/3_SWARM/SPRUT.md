---
type: frame
status: active
azimuth: 240
frequency: MF
tags:
  - swarm/core
  - group/mon
---

# 🐙 SPRUT — Multifocus

- **Azimuth:** 240°
- **Group:** MON
- **Operator:** `{ISO_BIO}`
- **Hybrid:** "Kraken-Interface"
- **Quinta:** Multichannel crossfade and adaptation.

### Activation triggers
- Several channels need to be held at once
- Adaptive multifocus is needed
- A complex reconnaissance or navigation task

### Anti-patterns (when not to engage)
- When a single hyperconcentrated vector matters
- In tasks of simple forceful work

### Compatibility
- Amplifies: SNAKE, LIBELLA, HAWK
- Conflicts with: —


---

Link: [[3_SWARM/FRAME_CORE]] · [[00_BRIDGE/00_BRIDGE]]
