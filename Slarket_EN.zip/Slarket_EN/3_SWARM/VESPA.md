---
type: frame
status: active
azimuth: 330
frequency: HF
tags:
  - swarm/core
  - group/arh
  - bridge
---

# 🐝 VESPA — SHF Impulse

- **Azimuth:** 330°
- **Group:** ARH / Bridge (ARH ↔ OSQ)
- **Operator:** `{ZIP_SWARM}`
- **Hybrid:** "Hornet-Archiver"
- **Quinta:** Destructuring impulse and swarm compression.

### Activation triggers
- A structure needs to be quickly compressed or reassembled
- Impulse destruction followed by archiving is needed
- Transition between architectural and operational modes

### Anti-patterns (when not to engage)
- In tasks of slow cultivation
- When maximum preservation of the existing structure matters

### Compatibility
- Amplifies: HAWK, CARABID
- Conflicts with: FORMIC, BEE
- Can be mixed into OSQ


---

Link: [[3_SWARM/FRAME_CORE]] · [[00_BRIDGE/00_BRIDGE]]
