---
type: frame
status: active
azimuth: 120
frequency: MF
tags:
  - swarm/core
  - group/arh
---

# 🐝 BEE — Alchemist-Creator

- **Azimuth:** 120°
- **Group:** ARH
- **Operator:** `{HONEY_CRYSTAL}`
- **Hybrid:** "Honeycomb-Builder"
- **Quinta:** Constructive service and distillation of Honey.

### Activation triggers
- Structure needs to be grown and strengthened
- Results need to be distilled into a stable form
- Architectural growth mode

### Anti-patterns (when not to engage)
- When fast destruction is needed
- When maximum speed and aggression matter
- In purely reconnaissance, covert modes

### Compatibility
- Amplifies: FORMIC, SPIDER, DOG, FUNGY
- Conflicts with: HAWK, WASP


---

Link: [[3_SWARM/FRAME_CORE]] · [[00_BRIDGE/00_BRIDGE]]
