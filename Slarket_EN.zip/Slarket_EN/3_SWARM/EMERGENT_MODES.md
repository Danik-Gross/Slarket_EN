---
type: modes
status: active
version: 2.1
tags:
  - slarket/swarm
  - emergent
---

# EMERGENT_MODES // MACRO-MODES OF THE SWARM

> Stable states arising when several rods work in concert.  
> Weights = **channel strengths** (they need not sum to 100%).  
> The composition can be assembled in `{...}` according to [[2_GLIDERS/GLIDER_SYNTAX]].

**Links:** [[3_SWARM/FRAME_CORE]] · [[3_SWARM/INTERACTION_MATRIX]] · [[4_HONEY/WEIGHT_MODULATION]] 

---

## OSQ dominant

### 1. Assault afterburner
- **Composition:** CARABID + HAWK  
- **Strengths (guideline):** CARABID ~75% · HAWK ~90%  
- **Quinta:** Inertial breakthrough + HF capture  
- **Entry:** Speed and force are needed  
- **Risk:** Overload, loss of precision  
- **Example assembly:** `{CARABID:75%_HAWK:90%}`

### 2. Surgical capture
- **Composition:** MANTIS + WASP  
- **Strengths:** MANTIS ~80% · WASP ~45%  
- **Quinta:** Sniper intake + pinpoint injection  
- **Entry:** Maximum precision  
- **Risk:** Focus too narrow  
- **Example assembly:** `{MANTIS:80%_WASP:45%}`

---

## MON dominant

### 3. Deep reconnaissance + camouflage
- **Composition:** SNAKE + SPRUT + LIBELLA  
- **Strengths:** SNAKE ~70% · SPRUT ~55% · LIBELLA ~40%  
- **Quinta:** Hidden channels + multifocus + 360°  
- **Entry:** Unknown or hostile environment  
- **Risk:** Loss of speed of action  
- **Example assembly:** `{SNAKE:70%_SPRUT:55%_LIBELLA:40%}`

---

## ARH dominant

### 4. Architectural growth
- **Composition:** BEE + SPIDER + FORMIC  
- **Strengths:** BEE ~70% · SPIDER ~55% · FORMIC ~40%  
- **Quinta:** Creation + graph weaving + logistics  
- **Entry:** Building and holding a structure (Honey, protocols)  
- **Risk:** Slowness  
- **Example assembly:** `{BEE:70%_SPIDER:55%_FORMIC:40%}`

### 5. Total overview + archiving
- **Composition:** LIBELLA + VESPA + SCOLOP  
- **Strengths:** LIBELLA ~65% · VESPA ~50% · SCOLOP ~35%  
- **Quinta:** 360° + structural compression + segmentation  
- **Entry:** Completing a cycle, cleaning, conservation  
- **Risk:** Excessive conservation  
- **Example assembly:** `{LIBELLA:65%_VESPA:50%_SCOLOP:35%}`

---

## Calibration and rest

### 6. Zero state
- **Composition:** rods in phase waiting `[_]`  
- **Quinta:** Gyrotor at rest (NULL)  
- **Entry:** After heavy load or at rest  
- **Risk:** Stagnation if held too long  
- **Link:** [[4_HONEY/GYROTOR_CONTROL]]

### 7. AYMS calibration (pre-combat)
- **Composition:** HAWK + MANTIS + SPRUT (+ WASP / DOG as needed)  
- **Strengths (guideline):** HAWK ~85% · MANTIS ~60% · SPRUT ~40% · WASP ~25% · DOG ~15%  
- **Quinta:** Pure intent + the drawn bowstring of experience  
- **Entry:** Before TARGET, assault, Z-Transition, complex modulation  
- **Risk:** Excessive reflection  
- **Example assembly:** `{HAWK:85%_MANTIS:60%_SPRUT:40%_WASP:25%}`  
- **Link:**  [[4_HONEY/AYMS]]

---

## SYS / mycelium (FUNGY)

### 8. Mycelial stitching
- **Composition:** FUNGY + FORMIC + SCOLOP  
- **Strengths (guideline):** FUNGY ~70% · FORMIC ~45% · SCOLOP ~30%  
- **Quinta:** Linking several rods/circuits without a single centre  
- **Entry:** A network is needed, not a hierarchy; bypassing the direct lines of OSQ/MON/ARH  
- **Risk:** Slow sprouting; conflict with the speed of HAWK/WASP  
- **Example assembly:** `{FUNGY:70%_FORMIC:45%_SCOLOP:30%}`

### 9. Spore release
- **Composition:** FUNGY + BEE + ([[GATEWAY]] gateway)  
- **Strengths:** FUNGY ~65% · BEE ~50%  
- **Quinta:** Packing a transit `{...}` for a foreign Nagwa (not to be confused with inward Honey)  
- **Entry:** An outward landing is needed, not an entry in 4_HONEY  
- **Risk:** Sending an internal protocol "as is" without a key cut to the environment's lock  
- **Link:** [[4_HONEY/RECIPE_TRANSMISSION]] · [[4_HONEY/NAGWA]] · [[GATEWAY]]

---

## Notes

1. Modes can be combined; channel strengths are independent.  
2. ISO in a mode's assembly — only if **isomerism** of the whole assembly is needed as it sprouts. 
3. Conflict inside a mode → `{SKERN[…]}`.  
4. GATEWAY is not a Swarm Rod: in mode 9 it is the release channel, not "one more player" in the composition.  

---

> Modes are not costumes. They are coordinated vectors of the Swarm.
