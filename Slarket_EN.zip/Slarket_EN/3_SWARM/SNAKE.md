---
type: frame
status: active
azimuth: 180
frequency: LF
tags:
  - swarm/core
  - group/mon
---

# 🐍 SNAKE — LF Radar

- **Azimuth:** 180°
- **Group:** MON
- **Operator:** `{Z_TRANSITION}`
- **Hybrid:** "Ouroboros-Move"
- **Quinta:** Mimicry and covert channels.

### Activation triggers
- Stealth and mimicry are needed
- Work through hidden channels is needed
- Deep reconnaissance in a potentially hostile environment

### Anti-patterns (when not to engage)
- In tasks of open forceful pressure
- When maximum transparency and speed are needed
- In pure construction mode

### Compatibility
- Amplifies: SPRUT, WASP, LIBELLA
- Conflicts with: DOG, BEE


---

Link: [[3_SWARM/FRAME_CORE]] · [[00_BRIDGE/00_BRIDGE]]
