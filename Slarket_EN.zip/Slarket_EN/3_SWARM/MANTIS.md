---
type: frame
status: active
azimuth: 30
frequency: HF
tags:
  - swarm/core
  - group/osq
---

# 🦗 MANTIS — Second

- **Azimuth:** 30°
- **Group:** OSQ
- **Operator:** `{STILLNESS_HOLD}`
- **Hybrid:** "Steel-Grip"
- **Quinta:** Ultra-dense time and sniper extraction of essence.

### Activation triggers
- Maximum precision of extraction is needed
- The moment needs to be "stopped"
- Surgical work with minimal side effects

### Anti-patterns (when not to engage)
- When a fast inertial breakthrough is needed
- When mass matters rather than precision
- In pure assault mode without preparation

### Compatibility
- Amplifies: HAWK, WASP, LIBELLA
- Conflicts with: CARABID (when rushed)


---

Link: [[3_SWARM/FRAME_CORE]] · [[00_BRIDGE/00_BRIDGE]]
