---
type: frame
status: active
azimuth: 150
frequency: LF
tags:
  - swarm/core
  - group/arh
---

# 🕷️ SPIDER — LF Architect

- **Azimuth:** 150°
- **Group:** ARH
- **Operator:** `{PAUTINA_CORE}`
- **Hybrid:** "Arachne-Text"
- **Quinta:** Fractal weaving of the graph of connections.

### Activation triggers
- A network of connections needs to be woven and strengthened
- Fractal elaboration of the structure is needed
- Long-term architectural construction

### Anti-patterns (when not to engage)
- When a fast forceful breakthrough is needed
- When simplicity and directness matter
- In impulse-destruction mode

### Compatibility
- Amplifies: BEE, FORMIC, SCOLOP
- Conflicts with: CARABID


---

Link: [[3_SWARM/FRAME_CORE]] · [[00_BRIDGE/00_BRIDGE]]
