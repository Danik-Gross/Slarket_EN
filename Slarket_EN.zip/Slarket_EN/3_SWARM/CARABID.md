---
type: frame
status: active
azimuth: 45
frequency: MF
tags:
  - swarm/core
  - group/osq
---

# 🪲 CARABID — Terminator-Tank

- **Azimuth:** 45°
- **Group:** OSQ
- **Operator:** `{GYRO_FLYWHEEL}`
- **Hybrid:** "Chitin-Ram"
- **Quinta:** Breakthrough inertia and heavy armour.

### Activation triggers
- A forceful breakthrough is needed
- Resistance needs to be pushed through
- Assault afterburner

### Anti-patterns (when not to engage)
- In tasks of subtle reconnaissance and camouflage
- When flexibility and multichannelness matter
- In deep-observation mode

### Compatibility
- Amplifies: HAWK, DOG
- Conflicts with: SPIDER, LIBELLA


---

Link: [[3_SWARM/FRAME_CORE]] · [[00_BRIDGE/00_BRIDGE]]
