---
type: frame
status: active
azimuth: 0
frequency: HF
tags:
  - swarm/core
  - group/osq
---

# 🦅 HAWK — HF Puncture

- **Azimuth:** 0°
- **Group:** OSQ
- **Operator:** `{FLASH_QUINT}`
- **Hybrid:** "Orion-Zenith"
- **Quinta:** Hyperconcentrated target capture and noise filtering at high speed.

### Activation triggers
- Fast, high-precision target capture is needed
- Noise must be cut off at high speed
- Start of an assault afterburner

### Anti-patterns (when not to engage)
- When slow, deep work is needed
- In tasks of stabilizing and holding the base
- When excess speed creates parasitic noise

### Compatibility
- Amplifies: MANTIS, WASP, CARABID
- Conflicts with: DOG, BEE, FUNGY


---

Link: [[3_SWARM/FRAME_CORE]] · [[00_BRIDGE/00_BRIDGE]]
